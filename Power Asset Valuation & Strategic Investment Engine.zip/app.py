from flask import Flask, render_template, request, redirect, url_for, flash
import sqlite3
from datetime import datetime

app = Flask(__name__)
app.secret_key = "voltaris-demo"
DB = "voltaris.db"

def db():
    c = sqlite3.connect(DB)
    c.row_factory = sqlite3.Row
    return c

def init_db():
    c = db()
    c.executescript("""
    CREATE TABLE IF NOT EXISTS assets(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        technology TEXT NOT NULL,
        capacity_mw REAL NOT NULL,
        age_years REAL NOT NULL,
        book_value REAL NOT NULL,
        replacement_cost REAL NOT NULL,
        annual_revenue REAL NOT NULL,
        annual_opex REAL NOT NULL,
        availability REAL NOT NULL
    );
    CREATE TABLE IF NOT EXISTS valuations(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        asset_id INTEGER NOT NULL,
        scenario TEXT NOT NULL,
        growth REAL NOT NULL,
        discount_rate REAL NOT NULL,
        terminal_growth REAL NOT NULL,
        enterprise_value REAL NOT NULL,
        equity_value REAL NOT NULL,
        value_per_mw REAL NOT NULL,
        created_at TEXT NOT NULL,
        FOREIGN KEY(asset_id) REFERENCES assets(id)
    );
    """)
    if c.execute("SELECT COUNT(*) FROM assets").fetchone()[0] == 0:
        c.executemany("""INSERT INTO assets
        (name,technology,capacity_mw,age_years,book_value,replacement_cost,
         annual_revenue,annual_opex,availability)
        VALUES (?,?,?,?,?,?,?,?,?)""", [
            ("Yamuna Solar Asset","Solar",75,3,310000000,390000000,92000000,14500000,96),
            ("Rajasthan Wind Asset","Wind",120,5,580000000,760000000,138000000,27000000,91),
            ("Industrial Hybrid Plant","Solar + Storage",40,2,265000000,335000000,71000000,12500000,94)
        ])
    c.commit()
    c.close()

def valuation(a, growth, discount, terminal_growth):
    # Five-year unlevered cash-flow valuation.
    base_cf = a["annual_revenue"] - a["annual_opex"]
    pv = 0
    cash = base_cf
    for year in range(1, 6):
        cash *= (1 + growth)
        pv += cash / ((1 + discount) ** year)
    terminal = cash * (1 + terminal_growth) / (discount - terminal_growth)
    enterprise = pv + terminal / ((1 + discount) ** 5)
    # Use book value as a simple debt proxy for a portfolio demonstration.
    equity = enterprise - max(0, a["book_value"] * 0.20)
    value_per_mw = enterprise / a["capacity_mw"] if a["capacity_mw"] else 0
    return enterprise, equity, value_per_mw

@app.route("/")
def dashboard():
    c = db()
    assets = c.execute("SELECT * FROM assets ORDER BY id DESC").fetchall()
    valuations = c.execute("""
        SELECT v.*, a.name asset_name, a.technology
        FROM valuations v JOIN assets a ON a.id=v.asset_id
        ORDER BY v.enterprise_value DESC
    """).fetchall()
    stats = {
        "assets": len(assets),
        "valuations": len(valuations),
        "capacity": c.execute("SELECT COALESCE(SUM(capacity_mw),0) FROM assets").fetchone()[0],
        "value": c.execute("SELECT COALESCE(SUM(enterprise_value),0) FROM valuations").fetchone()[0]
    }
    c.close()
    return render_template("dashboard.html", assets=assets, valuations=valuations, stats=stats)

@app.route("/assets")
def assets():
    c = db()
    rows = c.execute("SELECT * FROM assets ORDER BY id DESC").fetchall()
    c.close()
    return render_template("assets.html", assets=rows)

@app.route("/assets/new", methods=["GET","POST"])
def asset_new():
    if request.method == "POST":
        try:
            values = (
                request.form["name"].strip(),
                request.form["technology"].strip(),
                float(request.form["capacity_mw"]),
                float(request.form["age_years"]),
                float(request.form["book_value"]),
                float(request.form["replacement_cost"]),
                float(request.form["annual_revenue"]),
                float(request.form["annual_opex"]),
                float(request.form["availability"])
            )
            if not values[0] or not values[1] or values[2] <= 0 or values[3] < 0:
                raise ValueError
            if min(values[4:8]) < 0 or not 0 < values[8] <= 100:
                raise ValueError
            c = db()
            c.execute("""INSERT INTO assets
            (name,technology,capacity_mw,age_years,book_value,replacement_cost,
             annual_revenue,annual_opex,availability)
            VALUES (?,?,?,?,?,?,?,?,?)""", values)
            c.commit(); c.close()
            flash("Power asset added.", "success")
            return redirect(url_for("assets"))
        except (ValueError, KeyError):
            flash("Enter valid asset data.", "error")
    return render_template("asset_form.html")

@app.route("/valuations")
def valuations():
    c = db()
    rows = c.execute("""
        SELECT v.*, a.name asset_name, a.technology, a.capacity_mw
        FROM valuations v JOIN assets a ON a.id=v.asset_id
        ORDER BY v.enterprise_value DESC
    """).fetchall()
    c.close()
    return render_template("valuations.html", valuations=rows)

@app.route("/valuations/new", methods=["GET","POST"])
def valuation_new():
    c = db()
    assets = c.execute("SELECT * FROM assets ORDER BY name").fetchall()
    c.close()
    if request.method == "POST":
        try:
            asset_id = int(request.form["asset_id"])
            scenario = request.form["scenario"].strip()
            growth = float(request.form["growth"]) / 100
            discount = float(request.form["discount_rate"]) / 100
            terminal = float(request.form["terminal_growth"]) / 100
            asset = next((a for a in assets if a["id"] == asset_id), None)
            if not asset or not scenario or discount <= terminal or discount <= 0:
                raise ValueError
            ev, equity, per_mw = valuation(asset, growth, discount, terminal)
            c = db()
            c.execute("""INSERT INTO valuations
            (asset_id,scenario,growth,discount_rate,terminal_growth,
             enterprise_value,equity_value,value_per_mw,created_at)
            VALUES (?,?,?,?,?,?,?,?,?)""",
            (asset_id,scenario,growth,discount,terminal,ev,equity,per_mw,
             datetime.now().strftime("%Y-%m-%d %H:%M")))
            c.commit(); c.close()
            flash("Asset valuation completed.", "success")
            return redirect(url_for("valuations"))
        except (ValueError, KeyError):
            flash("Check valuation assumptions.", "error")
    return render_template("valuation_form.html", assets=assets)

@app.route("/valuations/<int:vid>")
def valuation_detail(vid):
    return redirect(url_for("valuations"))

