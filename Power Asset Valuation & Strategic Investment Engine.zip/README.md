# Voltaris — Power Asset Valuation & Strategic Investment Engine

Voltaris is a full-stack financial and engineering analytics platform for valuing electricity-generation assets and evaluating strategic investment scenarios.

## Features
- Power asset portfolio management
- Solar, wind and hybrid asset modeling
- Capacity and availability tracking
- Book value and replacement-cost analysis
- Revenue and OPEX modeling
- Five-year DCF valuation
- Enterprise value and equity value
- Value per MW
- Growth, discount-rate and terminal-growth scenarios
- Strategic valuation comparison
- Executive dashboard

## Technology
Python, Flask, SQLite, Jinja2, HTML5 and CSS3.

## Run
```bash
pip install -r requirements.txt
python app.py
```
Open `http://127.0.0.1:5000`.

## Valuation Model
Base annual cash flow:

`Annual Cash Flow = Annual Revenue − Annual OPEX`

Five-year DCF:

`Enterprise Value = PV(Forecast Cash Flows) + PV(Terminal Value)`

Terminal value:

`Terminal Value = Year-5 Cash Flow × (1 + Terminal Growth) / (Discount Rate − Terminal Growth)`

The demonstration model uses scenario inputs rather than live market data.

## Portfolio Value
Voltaris combines electrical infrastructure concepts with corporate finance, valuation, strategic investment analysis and business decision-making.

## Future Enhancements
- Asset-level depreciation schedules
- Debt and financing structures
- Power-price forecasting
- Renewable generation uncertainty
- Monte Carlo valuation
- Comparable asset multiples
- Sensitivity heatmaps
- Acquisition premium modeling
- Portfolio optimization
- CSV/PDF reporting
- PostgreSQL support

## Author
Snehil Raj — B.Tech EEE, VIT Vellore
